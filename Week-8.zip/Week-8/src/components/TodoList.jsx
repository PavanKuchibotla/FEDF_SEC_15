import React from "react";

function TodoList({ tasks, onDelete, onToggle }) {
  return (
    <ul style={{ listStyle: "none", padding: 0 }}>
      {tasks.length === 0 && (
        <p style={{ textAlign: "center", color: "#8d6e63" }}>
          No tasks yet — add one above!
        </p>
      )}

      {tasks.map((task) => (
        <li
          key={task.id}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "0.7rem 1rem",
            margin: "0.5rem 0",
            backgroundColor: "#fef6ee",
            borderRadius: "8px",
            border: "1px solid #d7ccc8",
          }}
        >
          <span
            onClick={() => onToggle(task.id)}
            style={{
              textDecoration: task.completed ? "line-through" : "none",
              color: task.completed ? "#9e9e9e" : "#3e2723",
              cursor: "pointer",
              flex: 1,
            }}
          >
            {task.text}
          </span>

          <button
            onClick={() => onDelete(task.id)}
            style={{
              backgroundColor: "#c62828",
              color: "white",
              border: "none",
              padding: "0.3rem 0.7rem",
              borderRadius: "6px",
              cursor: "pointer",
            }}
          >
            ✕
          </button>
        </li>
      ))}
    </ul>
  );
}

export default TodoList;