import React, { useState } from "react";

function TodoInput({ onAdd }) {
  const [task, setTask] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onAdd(task);
    setTask("");
  };

  return (
    <form
      onSubmit={handleSubmit}
      style={{
        display: "flex",
        gap: "0.5rem",
        margin: "1rem 0",
      }}
    >
      <input
        type="text"
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Enter a new task..."
        style={{
          flex: 1,
          padding: "0.6rem 1rem",
          borderRadius: "8px",
          border: "1.5px solid #cbb09c",
          outline: "none",
        }}
      />
      <button
        type="submit"
        style={{
          backgroundColor: "#8d6e63",
          color: "white",
          border: "none",
          padding: "0.6rem 1rem",
          borderRadius: "8px",
          cursor: "pointer",
          fontWeight: "600",
        }}
      >
        Add
      </button>
    </form>
  );
}

export default TodoInput;